import java.lang.*;
import views.*;

public class Start
{
	public static void main(String[] args)
	{
		LoginFrame lf=new LoginFrame();
		lf.setVisible(true);
	}
}