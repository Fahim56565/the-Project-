package controllers;

import java.lang.*;
import models.*;

public class BookBorrowController
{
	public void insertBookBorrow(BookBorrow bb)
	{
		BookBorrow bbs[]=this.getAllBookBorrow();
		
		for(int i=0;i<100;i++)
		{
			if(bbs[i]==null)
			{
				bbs[i]=bb;
				break;
			}
		}
		
		this.write(bbs);
	}
	
	public void updateBookBorrow(BookBorrow bb)
	{
		BookBorrow bbs[]=this.getAllBookBorrow();
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBookBorrowId().equals(bb.getBookBorrowId()))
				{
					bbs[i]=bb;
				}
			}
		}
		
		this.write(bbs);
	}
	
	public void deleteBookBorrow(String bookBorrowId)
	{
		BookBorrow bbs[]=this.getAllBookBorrow();
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBookBorrowId().equals(bookBorrowId))
				{
					bbs[i]=null;
				}
			}
		}
		
		this.write(bbs);
	}
	
	public BookBorrow searchBookBorrow(String bookBorrowId)
	{
		BookBorrow bbs[]=this.getAllBookBorrow();
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBookBorrowId().equals(bookBorrowId))
				{
					return bbs[i];
				}
			}
		}
		
		
		return null;
	}
	
	public BookBorrow[] searchBookBorrowByUserId(String userId)
	{
		BookBorrow bbs[]=this.getAllBookBorrow();
		BookBorrow targetBBs[]=new BookBorrow[100];
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getUserId().equals(userId))
				{
					targetBBs[i]=bbs[i];
				}
			}
		}
		
		return targetBBs;
	}
	
	public BookBorrow[] searchBookBorrowByBookId(String bookId)
	{
		BookBorrow bbs[]=this.getAllBookBorrow();
		BookBorrow targetBBs[]=new BookBorrow[100];
		
		for(int i=0;i<bbs.length;i++)
		{
			if(bbs[i]!=null)
			{
				if(bbs[i].getBookId().equals(bookId))
				{
					targetBBs[i]=bbs[i];
				}
			}
		}
		
		return targetBBs;
	}
	
	public BookBorrow[] getAllBookBorrow()
	{
		String fileName="controllers/data/bookBorrows.txt";
		FileIO fio=new FileIO();
		String data[]=fio.readFile(fileName);
		BookBorrow bbs[]=new BookBorrow[100];
		BookBorrow bb=new BookBorrow();
		for(int i=0;i<data.length;i++)
		{
			if(data[i]!=null)
			{
				
				bbs[i]=bb.formBookBorrow(data[i]);
			}
		}
		
		return bbs;
		
	}
	
	public void write(BookBorrow bookBorrow[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(bookBorrow[i]!=null)
			{
				data[i]=bookBorrow[i].toStringBookBorrow();
			}
		}
		
		FileIO fio=new FileIO();
		String fileName="controllers/data/bookBorrows.txt";
		fio.writeFile(fileName, data);
	}

	
	
	
}