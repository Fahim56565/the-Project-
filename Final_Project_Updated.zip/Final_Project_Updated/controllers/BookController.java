package controllers;
import java.lang.*;
import models.*;

public class BookController
{
	public void insertBook(Book b)
	{
		Book books[]=this.getAllBook();
		
		for(int i=0;i<books.length;i++)
		{
			if(books[i]==null)
			{
				books[i]=b;
				break;
			}
		}
		
		this.write(books);
		
		
	}
	
	public void updateBook(Book b)
	{
		Book books[]=this.getAllBook();
		
		for(int i=0;i<books.length;i++)
		{
			if(books[i]!=null)
			{
				if(books[i].getBookId().equals(b.getBookId()))
				{
					books[i]=b;
				}
			}
		}
		
		this.write(books);
	}
	
	public void deleteBook(String bookId)
	{
		Book books[]=this.getAllBook();
		
		for(int i=0;i<books.length;i++)
		{
			if(books[i]!=null)
			{
				if(books[i].getBookId().equals(bookId))
				{
					books[i]=null;
				}
			}
		}
		
		this.write(books);
	}
	
	public Book searchBook(String bookId)
	{
		Book books[]=this.getAllBook();
		
		for(int i=0;i<books.length;i++)
		{
			if(books[i]!=null)
			{
				if(books[i].getBookId().equals(bookId))
				{
					
					return books[i];
				}
			}
			
		}
		
		return null;
	}
	
	public Book[] getAllBook()
	{
		String fileName="controllers/data/books.txt";
		FileIO fio=new FileIO();
		String values[]=fio.readFile(fileName);
		
		Book books[]=new Book[100];
		
		Book b=new Book();
		
		for(int i=0;i<values.length;i++)
		{
			if(values[i]!=null)
			{
				if(books[i]==null)
				{
					books[i]=b.formBook(values[i]);
				}
			}
			
		}
		
		return books;
	}
	
	public void write(Book books[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(books[i]!=null)
			{
				data[i]=books[i].toStringBook();
			}
		}
		
		String fileName="controllers/data/books.txt";
		
		FileIO fio=new FileIO();
		fio.writeFile(fileName, data);
	}
}