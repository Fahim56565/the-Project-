package controllers;

import java.lang.*;
import models.*;

public class BookReturnController
{
	public void insertBookReturn(BookReturn br)
	{
		BookReturn brs[]=this.getAllBookReturn();
		
		for(int i=0;i<100;i++)
		{
			if(brs[i]==null)
			{
				brs[i]=br;
				break;
			}
		}
		
		this.write(brs);
	}
	
	public void updateBookReturn(BookReturn br)
	{
		BookReturn brs[]=this.getAllBookReturn();
		
		for(int i=0;i<brs.length;i++)
		{
			if(brs[i]!=null)
			{
				if(brs[i].getBookReturnId().equals(br.getBookReturnId()))
				{
					brs[i]=br;
				}
			}
		}
		
		this.write(brs);
	}
	
	public void deleteBookReturn(String BookReturnId)
	{
		BookReturn brs[]=this.getAllBookReturn();
		
		for(int i=0;i<brs.length;i++)
		{
			if(brs[i]!=null)
			{
				if(brs[i].getBookReturnId().equals(BookReturnId))
				{
					brs[i]=null;
				}
			}
		}
		
		this.write(brs);
	}
	
	public BookReturn searchBookReturn(String BookReturnId)
	{
		BookReturn brs[]=this.getAllBookReturn();
		
		for(int i=0;i<brs.length;i++)
		{
			if(brs[i]!=null)
			{
				if(brs[i].getBookReturnId().equals(BookReturnId))
				{
					return brs[i];
				}
			}
		}
		
		
		return null;
	}
	
	public BookReturn[] searchBookReturnByUserId(String userId)
	{
		BookReturn brs[]=this.getAllBookReturn();
		BookReturn targetbrs[]=new BookReturn[100];
		
		for(int i=0;i<brs.length;i++)
		{
			if(brs[i]!=null)
			{
				if(brs[i].getUserId().equals(userId))
				{
					targetbrs[i]=brs[i];
				}
			}
		}
		
		return targetbrs;
	}
	
	public BookReturn[] searchBookReturnByBookId(String bookId)
	{
		BookReturn brs[]=this.getAllBookReturn();
		BookReturn targetbrs[]=new BookReturn[100];
		
		for(int i=0;i<brs.length;i++)
		{
			if(brs[i]!=null)
			{
				if(brs[i].getBookId().equals(bookId))
				{
					targetbrs[i]=brs[i];
				}
			}
		}
		
		return targetbrs;
	}
	
	public BookReturn[] getAllBookReturn()
	{
		String fileName="controllers/data/bookReturns.txt";
		FileIO fio=new FileIO();
		String data[]=fio.readFile(fileName);
		BookReturn brs[]=new BookReturn[100];
		BookReturn br=new BookReturn();
		for(int i=0;i<data.length;i++)
		{
			if(data[i]!=null)
			{
				
				brs[i]=br.formBookReturn(data[i]);
			}
		}
		
		return brs;
		
	}
	
	public void write(BookReturn brs[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(brs[i]!=null)
			{
				data[i]=brs[i].toStringBookReturn();
			}
		}
		
		FileIO fio=new FileIO();
		String fileName="controllers/data/bookReturns.txt";
		fio.writeFile(fileName, data);
	}

	
	
	
}