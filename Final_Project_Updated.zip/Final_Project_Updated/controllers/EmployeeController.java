package controllers;
import java.lang.*;
import models.*;

public class EmployeeController
{
	public void insertEmployee(Employee e)
	{
		Employee emps[]=this.getAllEmployee();
		
		for(int i=0;i<emps.length;i++)
		{
			if(emps[i]==null)
			{
				emps[i]=e;
				break;
			}
		}
		
		this.write(emps);
		
		
	}
	
	public void updateEmployee(Employee e)
	{
		Employee emps[]=this.getAllEmployee();
		
		for(int i=0;i<emps.length;i++)
		{
			if(emps[i]!=null)
			{
				if(emps[i].getUserId().equals(e.getUserId()))
				{
					emps[i]=e;
				}
			}
		}
		
		this.write(emps);
	}
	
	public void deleteEmployee(String userId)
	{
		Employee emps[]=this.getAllEmployee();
		
		for(int i=0;i<emps.length;i++)
		{
			if(emps[i]!=null)
			{
				if(emps[i].getUserId().equals(userId))
				{
					emps[i]=null;
				}
			}
		}
		
		this.write(emps);
	}
	
	public Employee searchEmployee(String userId)
	{
		Employee emps[]=this.getAllEmployee();
		
		for(int i=0;i<emps.length;i++)
		{
			if(emps[i]!=null)
			{
				if(emps[i].getUserId().equals(userId))
				{
					
					return emps[i];
				}
			}
			
		}
		
		return null;
	}
	
	public Employee[] getAllEmployee()
	{
		String fileName="controllers/data/employees.txt";
		FileIO fio=new FileIO();
		String values[]=fio.readFile(fileName);
		
		Employee emps[]=new Employee[100];
		
		Employee e=new Employee();
		
		for(int i=0;i<values.length;i++)
		{
			if(values[i]!=null)
			{
				if(emps[i]==null)
				{
					emps[i]=e.formEmployee(values[i]);
				}
			}
			
		}
		
		return emps;
	}
	
	public void write(Employee emps[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(emps[i]!=null)
			{
				data[i]=emps[i].toStringEmployee();
			}
		}
		
		String fileName="controllers/data/employees.txt";
		
		FileIO fio=new FileIO();
		fio.writeFile(fileName, data);
	}
}