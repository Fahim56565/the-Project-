package models;
import java.lang.*;

public class Book
{
	private String bookId;
	private String name;
	private String catagory;
	private String authorName;
	private String isbn;
	private int noOfPage;
	private float price;
	private int availableQuantity;
	private String details;
	
	public Book()
	{
	}
	
	public Book(String bookId, String name, String catagory, String authorName, String isbn, int noOfPage, float price, int availableQuantity, String details)
	{
		this.bookId=bookId;
		this.name=name;
		this.catagory=catagory;
		this.authorName=authorName;
		this.isbn=isbn;
		this.noOfPage=noOfPage;
		this.price=price;
		this.availableQuantity=availableQuantity;
		this.details=details;
	}
	
	public void setBookId(String bookId)
	{
		this.bookId=bookId;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public void setCatagory(String catagory)
	{
		this.catagory=catagory;
	}
	
	public void setAuthorName(String authorName)
	{
		this.authorName=authorName;
	}
	
	public void setIsbn(String isbn)
	{
		this.isbn=isbn;
	}
	
	public void setNoOfPage(int noOfPage)
	{
		this.noOfPage=noOfPage;
	}
	
	public void setPrice(float price)
	{
		this.price=price;
	}
	
	public void setAvailableQuantity(int availableQuantity)
	{
		this.availableQuantity=availableQuantity;
	}
	
	public void setDetails(String details)
	{
		this.details=details;
	}
	
	public String getBookId()
	{
		return this.bookId;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public String getCatagory()
	{
		return this.catagory;
	}
	
	public String getAuthorName()
	{
		return this.authorName;
	}
	
	public String getIsbn()
	{
		return this.isbn;
	}
	
	public int getNoOfPage()
	{
		return this.noOfPage;
	}
	
	public float getPrice()
	{
		return this.price;
	}
	
	public int getAvailableQuantity()
	{
		return this.availableQuantity;
	}
	
	public String getDetails()
	{
		return this.details;
	}
	
	public String toStringBook()
	{
		String str=this.bookId+","+this.name+","+this.catagory+","+this.authorName+","+this.isbn+","+this.noOfPage+","+this.price+","+this.availableQuantity+","+this.details+"\n";
		return str;
		
	}
	
	public Book formBook(String str)
	{
		String data[]=str.split(",");
		
		Book b=new Book();
		b.setBookId(data[0]);
		b.setName(data[1]);
		b.setCatagory(data[2]);
		b.setAuthorName(data[3]);
		b.setIsbn(data[4]);
		b.setNoOfPage(Integer.parseInt(data[5]));
		b.setPrice(Float.parseFloat(data[6]));
		b.setAvailableQuantity(Integer.parseInt(data[7]));
		b.setDetails(data[8]);
		
		return b;
	}
	
}