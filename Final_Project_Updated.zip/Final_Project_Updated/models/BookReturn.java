package models;
import java.lang.*;

public class BookReturn
{
	private String bookReturnId;
	private String bookId;
	private String userId;
	private String returnDate;
	
	public BookReturn()
	{
	}
	
	public BookReturn(String bookReturnId, String bookId, String userId, String returnDate)
	{
		this.bookReturnId=bookReturnId;
		this.bookId=bookId;
		this.userId=userId;
		this.returnDate=returnDate;
	}
	
	
	public void setBookReturnId(String bookReturnId)
	{
		this.bookReturnId=bookReturnId;
	}
	
	public void setBookId(String bookId)
	{
		this.bookId=bookId;
	}
	
	public void setUserId(String userId)
	{
		this.userId=userId;
	}
	
	public void setReturnDate(String returnDate)
	{
		this.returnDate=returnDate;
	}
	
	public String getBookReturnId()
	{
		return this.bookReturnId;
	}
	
	public String getBookId()
	{
		return this.bookId;
	}
	
	public String getUserId()
	{
		return this.userId;
	}
	
	public String getReturnDate()
	{
		return this.returnDate;
	}
	
	public String toStringBookReturn()
	{
		String str=this.bookReturnId+","+this.bookId+","+this.userId+","+this.returnDate+"\n";
		return str;
	}
	
	public BookReturn formBookReturn(String str)
	{
		String data[]=str.split(",");
		
		BookReturn br=new BookReturn();
		br.setBookReturnId(data[0]);
		br.setBookId(data[1]);
		br.setUserId(data[2]);
		br.setReturnDate(data[3]);
		return br;
		
	}
	
}