package models;
import java.lang.*;

public class Client extends User
{
	private String membershipType;
	
	public Client()
	{
		super();
	}
	
	public Client(String userId, String name, String gender,int age, String email, String phoneNo, String address, int role, String securityAns, String password, String membershipType)
	{
		super(userId,role,securityAns,password);
		this.name=name;
		this.gender=gender;
		this.age=age;
		this.email=email;
		this.phoneNo=phoneNo;
		this.address=address;
		this.membershipType=membershipType;
		
	}
	
	public void setMembershipType(String membershipType)
	{
		this.membershipType=membershipType;
	}
	
	public String getMembershipType()
	{
		return this.membershipType;
	}
	
	public String toStringClient()
	{
		String str=this.userId+","+this.name+","+this.gender+","+this.age+","+this.email+","+this.phoneNo+","+this.address+","+this.membershipType+"\n";
		return str;
	}
	
	public Client formClient(String str)
	{
		String data[]=str.split(",");
		
		Client c=new Client();
		c.setUserId(data[0]);
		c.setName(data[1]);
		c.setGender(data[2]);
		c.setAge(Integer.parseInt(data[3]));
		c.setEmail(data[4]);
		c.setPhoneNo(data[5]);
		c.setAddress(data[6]);
		c.setMembershipType(data[7]);
		
		return c;
	}
}
