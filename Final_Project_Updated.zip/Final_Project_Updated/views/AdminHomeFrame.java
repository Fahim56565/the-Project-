package views;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import models.*;
import controllers.*;


public class AdminHomeFrame extends JFrame implements ActionListener
{
	
	private JButton adminBtn, clientBtn, employeeBtn, bookBorrowBtn, bookReturnBtn,bookBtn,profileBtn, passBtn, logOutBtn;
	private JPanel panel;
	private User u;
	
	public AdminHomeFrame(User u)
	{
		
		super("Admin Home Frame");
		this.setSize(800,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.panel=new JPanel();
		this.panel.setLayout(null);
		
		
		this.adminBtn=new JButton("Admin operation");
		this.adminBtn.setBounds(50,50,150,30);
		this.adminBtn.addActionListener(this);
		this.panel.add(adminBtn);
		
		this.clientBtn=new JButton("Client operation");
		this.clientBtn.setBounds(210,50,150,30);
		this.clientBtn.addActionListener(this);
		this.panel.add(clientBtn);
		
		this.employeeBtn=new JButton("Employee operation");
		this.employeeBtn.setBounds(370,50,150,30);
		this.employeeBtn.addActionListener(this);
		this.panel.add(employeeBtn);
		
		this.bookBtn=new JButton("View All Book");
		this.bookBtn.setBounds(530,50,150,30);
		this.bookBtn.addActionListener(this);
		this.panel.add(bookBtn);
		
		this.bookReturnBtn=new JButton("View Book Return");
		this.bookReturnBtn.setBounds(50,100,150,30);
		this.bookReturnBtn.addActionListener(this);
		this.panel.add(bookReturnBtn);
		
		this.bookBorrowBtn=new JButton("View Book Borrow");
		this.bookBorrowBtn.setBounds(210,100,150,30);
		this.bookBorrowBtn.addActionListener(this);
		this.panel.add(bookBorrowBtn);
		
		this.profileBtn=new JButton("Update Profile");
		this.profileBtn.setBounds(370,100,150,30);
		this.profileBtn.addActionListener(this);
		this.panel.add(profileBtn);
		
		this.passBtn=new JButton("Update Password");
		this.passBtn.setBounds(530,100,150,30);
		this.passBtn.addActionListener(this);
		this.panel.add(passBtn);
		
		this.logOutBtn=new JButton("Log Out");
		this.logOutBtn.setBounds(690,100,100,30);
		this.logOutBtn.addActionListener(this);
		this.panel.add(logOutBtn);
		
		
		
		
		this.add(panel);
		this.u=u;
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(adminBtn.getText().equals(command))
		{
			AdminOperationFrame aof=new AdminOperationFrame(u);
			this.setVisible(false);
			aof.setVisible(true);
		}
		
		if(bookBtn.getText().equals(command))
		{
			this.setVisible(false);
			AllBookFrame abf=new AllBookFrame(this.u);
			abf.setVisible(true);
		}
		
		if(profileBtn.getText().equals(command))
		{
			this.setVisible(false);
			UpdateProfileFrame upf=new UpdateProfileFrame(this.u);
			upf.setVisible(true);
		}
	}
	
}
