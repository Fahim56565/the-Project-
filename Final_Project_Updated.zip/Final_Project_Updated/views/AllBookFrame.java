package views;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import models.*;
import controllers.*;

public class AllBookFrame extends JFrame implements ActionListener
{
	
	private JButton backBtn;
	private JTable bookTable;
	private JScrollPane bookTableSP;
	private JPanel panel;
	private User u;
	
	
	
	public AllBookFrame(User u)
	{
		super(" All Payment Frame");
		this.setSize(800,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.panel=new JPanel();
		this.panel.setLayout(null);
		
		
		this.backBtn=new JButton("back");
		this.backBtn.setBounds(50,50,100,30);
		this.backBtn.addActionListener(this);
		this.panel.add(backBtn);
		
		BookController  bkc=new BookController();
		Book bookList[]=bkc.getAllBook();
		
		//converting the payment type array in 2d String type array to put the values in the table beacuse in table there will be two dimention. one is row, other one is colomn.
		String bookData1[][]=new String[bookList.length][9];
		for(int i=0;i<bookList.length;i++)
		{
		
			if(bookList[i]!=null)
			{
				bookData1[i][0]=bookList[i].getBookId();
				bookData1[i][1]=bookList[i].getName();
				bookData1[i][2]=bookList[i].getCatagory();
				bookData1[i][3]=bookList[i].getAuthorName();
				bookData1[i][4]=bookList[i].getIsbn();
				bookData1[i][5]=String.valueOf(bookList[i].getNoOfPage());
				bookData1[i][6]=String.valueOf(bookList[i].getPrice());
				bookData1[i][7]=String.valueOf(bookList[i].getAvailableQuantity());
				bookData1[i][8]=bookList[i].getDetails();
			}
			
			
			
		}
		
		String head1[]={"ID","Name","Catagory","Author","ISBN","Page","Price","Quantity","Details"};
		//putting value and colomn name in the table.
		this.bookTable=new JTable(bookData1,head1);
		//adding scrolling bar in the table
		this.bookTableSP=new JScrollPane(bookTable);
		this.bookTableSP.setBounds(50,110,700,450);
		this.bookTable.setEnabled(false);
		this.panel.add(bookTableSP);
		
		this.panel.revalidate();
		this.panel.repaint();
		
		this.add(panel);
		
		this.u=u;
		
		
		
		
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		
		if(command.equals(backBtn.getText()))
		{
			//back button will take you to payment home page.
			AdminHomeFrame adf=new AdminHomeFrame(this.u);
			this.setVisible(false);
			adf.setVisible(true);
		}
	}
	
}