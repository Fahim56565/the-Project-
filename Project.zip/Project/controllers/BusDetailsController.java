package controllers;
import java.lang.*;
import models.*;

public class BusDetailsController
{
	public void insertBusDetails(BusDetails bs)
	{
		BusDetails busdetails[]=this.getAllBusDetails();
		
		for(int i=0;i<busdetails.length;i++)
		{
			if(busdetails[i]==null)
			{
				busdetails[i]=bs;
				break;
			}
		}
		this.write(busdetails);
	}
	
	public void updateBusDetails(BusDetails bs)
	{
		BusDetails busdetails[]=this.getAllBusDetails();
		
		for(int i=0;i<busdetails.length;i++)
		{
			if(busdetails[i]!=null)
			{
				if(busdetails[i].getBusId().equals(bs.getBusId()))
				{
					busdetails[i]=bs;
				}
			}
		}
		this.write(busdetails);
	}
	public void deleteBusDetails(String busId)
	{
		BusDetails busdetails[]=this.getAllBusDetails();
		
		for(int i=0;i<busdetails.length;i++)
		{
			if(busdetails[i]!=null)
			{
				if(busdetails[i].getBusId().equals(busId))
				{
					busdetails[i]=null;
				}
			}
		}
		this.write(busdetails);
	}
	public BusDetails searchBusDetails(String busId)
	{
		BusDetails busdetails[]=this.getAllBusDetails();
		
		for(int i=0;i<busdetails.length;i++)
		{
			if(busdetails[i]!=null)
			{
				if(busdetails[i].getBusId().equals(busId))
				{
					
					return busdetails[i];
				}
			}	
		}
		return null;
	}
	public BusDetails[] getAllBusDetails()
	{
		String fileName="controllers/data/busdetails.txt";
		FileIO fio=new FileIO();
		String values[]=fio.readFile(fileName);
		
		BusDetails busdetails[]=new BusDetails[100];
		
		BusDetails bs=new BusDetails();
		
		for(int i=0;i<values.length;i++)
		{
			if(values[i]!=null)
			{
				if(busdetails[i]==null)
				{
					busdetails[i]=bs.formBusDetails(values[i]);
				}
			}	
		}
		return busdetails;
	}
	public void write(BusDetails busdetails[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(busdetails[i]!=null)
			{
				data[i]= busdetails[i] .toStringBusdetails();

			}
		}
		
		String fileName="controllers/data/busdetails.txt";
		
		FileIO fio=new FileIO();
		fio.writeFile(fileName, data);
	}
}