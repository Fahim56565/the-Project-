package controllers;
import java.lang.*;
import models.*;

public class BusPassController
{
	public void insertBusPass(BusPass bp)
	{
		BusPass buspass[]=this.getAllBusPass();
		
		for(int i=0;i<100;i++)
		{
			if(buspass[i]==null)
			{
				buspass[i]=bp;
				break;
			}
		}
		this.write(buspass);
	}
	public void updateBusPass(BusPass bp)
	{
		BusPass buspass[]=this.getAllBusPass();
		
		for(int i=0;i<buspass.length;i++)
		{
			if(buspass[i]!=null)
			{
				if(buspass[i].getBusPassId().equals(bp.getBusPassId()))
				{
					buspass[i]=bp;
				}
			}
		}
		this.write(buspass);
	}
	public void deleteBusPass(String busPassId)
	{
		BusPass buspass[]=this.getAllBusPass();
		
		for(int i=0;i<buspass.length;i++)
		{
			if(buspass[i]!=null)
			{
				if(buspass[i].getBusPassId().equals(busPassId))
				{
					buspass[i]=null;
				}
			}
		}
		this.write(buspass);
	}
	public BusPass searchBusPass(String busPassId)
	{
		BusPass buspass[]=this.getAllBusPass();
		
		for(int i=0;i<buspass.length;i++)
		{
			if(buspass[i]!=null)
			{
				if(buspass[i].getBusPassId().equals(busPassId))
				{
					return buspass[i];
				}
			}
		}
		return null;
	}
	public BusPass[] searchBusPassByUserId(String passengerId)
	{
		BusPass buspass[]=this.getAllBusPass();
		BusPass targetBusPass[]=new BusPass[100];
		
		for(int i=0;i<buspass.length;i++)
		{
			if(buspass[i]!=null)
			{
				if(buspass[i].getPassengerId().equals(passengerId))
				{
					targetBusPass[i]=buspass[i];
				}
			}
		}
		return targetBusPass;
	}
	public BusPass[] searchBusPassByBusId(String busId)
	{
		BusPass buspass[]=this.getAllBusPass();
		BusPass targetBusPass[]=new BusPass[100];
		
		for(int i=0;i<buspass.length;i++)
		{
			if(buspass[i]!=null)
			{
				if(buspass[i].getBusId().equals(busId))
				{
					targetBusPass[i]=buspass[i];
				}
			}
		}
		return targetBusPass;
	}
	public BusPass[] getAllBusPass()
	{
		String fileName="controllers/data/buspass.txt";
		FileIO fio=new FileIO();
		String data[]=fio.readFile(fileName);
		BusPass buspass[]=new BusPass[100];
		BusPass bp=new BusPass();
		for(int i=0;i<data.length;i++)
		{
			if(data[i]!=null)
			{	
				buspass[i]=bp.formBusPass(data[i]);
			}
		}
		return buspass;	
	}
	public void write(BusPass busPass[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(busPass[i]!=null)
			{
				data[i]=busPass[i].toStringBusPass();
			}
		}	
		FileIO fio=new FileIO();
		String fileName="controllers/data/buspass.txt";
		fio.writeFile(fileName, data);
	}
}