package controllers;
import java.lang.*;
import models.*;

public class Passengercontroller 
{
	public void insertClient(Passenger p)
	{
		Passenger passengers[]=this.getAllPassenger();
		
		for(int i=0;i<passengers.length;i++)
		{
			if(passengers[i]==null)
			{
				passengers[i]=p;
				break;
			}
		}
		
		this.write(passengers);
		
		
	}
	
	public void updatePassenger(Passenger p)
	{
		Passenger passengers[]=this.getAllPassenger();
		
		for(int i=0;i<passengers.length;i++)
		{
			if(passengers[i]!=null)
			{
				if(passengers[i].getUserId().equals(p.getUserId()))
				{
					passengers[i]=p;
				}
			}
		}
		
		this.write(passengers);
	}
	
	public void deletePassenger(String userId)
	{
		Passenger passengers[]=this.getAllPassenger();
		
		for(int i=0;i<passengers.length;i++)
		{
			if(passengers[i]!=null)
			{
				if(passengers[i].getUserId().equals(userId))
				{
					passengers[i]=null;
				}
			}
		}
		
		this.write(passengers);
	}
	
	public Passenger searchPassenger(String userId)
	{
		Passenger passengers[]=this.getAllPassenger();
		
		for(int i=0;i<passengers.length;i++)
		{
			if(passengers[i]!=null)
			{
				if(passengers[i].getUserId().equals(userId))
				{
					
					return passengers[i];
				}
			}
			
		}
		
		return null;
	}
	
	public Passenger[] getAllPassenger()
	{
		String fileName="controllers/data/passengers.txt";
		FileIO fio=new FileIO();
		String values[]=fio.readFile(fileName);
		
		Passenger passengers[]=new Passenger[100];
		
		Passenger p=new Passenger();
		
		for(int i=0;i<values.length;i++)
		{
			if(values[i]!=null)
			{
				if(passengers[i]==null)
				{
					passengers[i]=p.formPassenger(values[i]);
				}
			}
			
		}
		
		return passengers;
	}
	
	public void write(Passenger passengers[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(passengers[i]!=null)
			{
				data[i]=passengers[i].toStringPassenger();
			}
		}
		
		String fileName="controllers/data/passengers.txt";
		
		FileIO fio=new FileIO();
		fio.writeFile(fileName, data);
	}
}