package controllers;

import java.lang.*;
import models.*;

public class TransactionController
{
	public void insertTransaction(Transaction ts)
	{
		Transaction transaction[]=this.getAllTransaction();
		
		for(int i=0;i<100;i++)
		{
			if(transaction[i]==null)
			{
				transaction[i]=ts;
				break;
			}
		}
		this.write(transaction);
	}
	public void updateTransaction(Transaction ts)
	{
		Transaction transaction[]=this.getAllTransaction();
		
		for(int i=0;i<transaction.length;i++)
		{
			if(transaction[i]!=null)
			{
				if(transaction[i].getTransactionId().equals(ts.getTransactionId()))
				{
					transaction[i]=ts;
				}
			}
		}
		this.write(transaction);
	}
	public void deleteTransaction(String transactionId)
	{
		Transaction transaction[]=this.getAllTransaction();
		
		for(int i=0;i<transaction.length;i++)
		{
			if(transaction[i]!=null)
			{
				if(transaction[i].getTransactionId().equals(transactionId))
				{
					transaction[i]=null;
				}
			}
		}
		this.write(transaction);
	}
	public Transaction searchTransaction(String transactionId)
	{
		Transaction transaction[]=this.getAllTransaction();
		
		for(int i=0;i<transaction.length;i++)
		{
			if(transaction[i]!=null)
			{
				if(transaction[i].getTransactionId().equals(transactionId))
				{
					return transaction[i];
				}
			}
		}
		return null;
	}
	public Transaction[] searchTransactionByPassengerId(String passengerId)
	{
		Transaction transaction[]=this.getAllTransaction();
		Transaction targettransaction[]=new Transaction[100];
		
		for(int i=0;i<transaction.length;i++)
		{
			if(transaction[i]!=null)
			{
				if(transaction[i].getPassengerId().equals(passengerId))
				{
					targettransaction[i]=transaction[i];
				}
			}
		}
		return targettransaction;
	}
	public Transaction[] searchTransactionBybusPassId(String busPassId )
	{
		Transaction transaction[]=this.getAllTransaction();
		Transaction targettransaction[]=new Transaction[100];
		
		for(int i=0;i<transaction.length;i++)
		{
			if(transaction[i]!=null)
			{
				if(transaction[i].getBusPassId().equals(busPassId))
				{
					targettransaction[i]=transaction[i];
				}
			}
		}
		return targettransaction;
	}
	public Transaction[] getAllTransaction()
	{
		String fileName="controllers/data/transaction.txt";
		FileIO fio=new FileIO();
		String data[]=fio.readFile(fileName);
		Transaction transaction[]=new Transaction[100];
		Transaction ts=new Transaction();
		for(int i=0;i<data.length;i++)
		{
			if(data[i]!=null)
			{
				
				transaction[i]=ts.formTransaction(data[i]);
			}
		}
		return transaction;
	}
	public void write(Transaction transaction[])
	{
		String data[]=new String[100];
		
		for(int i=0;i<data.length;i++)
		{
			if(transaction[i]!=null)
			{
				data[i]=transaction[i].toStringTransaction();
			}
		}
		
		FileIO fio=new FileIO();
		String fileName="controllers/data/transaction.txt";
		fio.writeFile(fileName, data);
	}	
}